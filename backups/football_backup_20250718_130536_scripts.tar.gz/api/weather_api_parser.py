import requests
from utils.db_connector import get_connection

WEATHER_API_KEY = "a1ec654deae246ee882145847250407"

def fetch_weather_data():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Берем 10 последних матчей без данных о погоде
    cursor.execute("""
        SELECT m.id, m.match_date 
        FROM matches m
        LEFT JOIN weather w ON m.id = w.match_id
        WHERE w.match_id IS NULL
        LIMIT 10
    """)
    
    for match in cursor.fetchall():
        weather = get_weather(match[1][:10])  # Дата без времени
        if weather:
            cursor.execute("""
                INSERT INTO weather (match_id, temperature, conditions, wind_speed)
                VALUES (?, ?, ?, ?)
            """, (match[0], weather["temp"], weather["conditions"], weather["wind"]))
    
    conn.commit()
    conn.close()

def get_weather(date):
    try:
        # Заглушка для теста - реальный запрос к API
        return {
            "temp": 18.5,
            "conditions": "Cloudy",
            "wind": 12.3
        }
    except Exception as e:
        print(f"Ошибка: {e}")
        return None

if __name__ == "__main__":
    fetch_weather_data()
    print("Парсинг погоды завершен!")
