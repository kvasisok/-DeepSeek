import requests
import sqlite3
import time
from datetime import datetime

# Конфигурация
FOOTBALL_API_KEY = "005b8a3887ac4870920d909a7e31c7c5"
DB_PATH = "/storage/emulated/0/FOOTBALL/db/football.db"
REQUEST_DELAY = 6.1

def get_db():
    return sqlite3.connect(DB_PATH)

def safe_request(url):
    """Безопасный запрос с задержкой"""
    time.sleep(REQUEST_DELAY)
    try:
        response = requests.get(url, headers={'X-Auth-Token': FOOTBALL_API_KEY})
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"Ошибка запроса {url}: {e}")
        return None

def process_team(team):
    """Обработка данных команды"""
    if not isinstance(team, dict):
        return None
        
    venue = team.get('venue', {})
    return (
        team.get('id'),
        team.get('name', '').strip(),
        team.get('shortName', '').strip(),
        venue.get('name', '').strip(),
        venue.get('latitude'),
        venue.get('longitude')
    )

def process_match(match):
    """Обработка данных матча"""
    if not isinstance(match, dict):
        return None
        
    score = match.get('score', {}).get('fullTime', {})
    match_date = match.get('utcDate', '')
    is_future = 1 if match_date and datetime.fromisoformat(match_date) > datetime.now() else 0
    
    return (
        match.get('id'),
        match.get('homeTeam', {}).get('id'),
        match.get('awayTeam', {}).get('id'),
        match_date,
        match.get('status'),
        score.get('home'),
        score.get('away'),
        0,  # weather_updated
        is_future
    )

def main():
    db = get_db()
    cursor = db.cursor()
    
    # Получаем данные Premier League
    print("Получаем команды...")
    teams_data = safe_request("http://api.football-data.org/v4/competitions/PL/teams")
    if teams_data:
        teams = [t for t in (process_team(team) for team in teams_data.get('teams', [])) if t]
        cursor.executemany('INSERT OR IGNORE INTO teams VALUES (?,?,?,?,?,?)', teams)
        print(f"Добавлено {len(teams)} команд")
    
    print("Получаем матчи...")
    matches_data = safe_request("http://api.football-data.org/v4/competitions/PL/matches")
    if matches_data:
        matches = [m for m in (process_match(match) for match in matches_data.get('matches', [])) if m]
        cursor.executemany('''
            INSERT OR REPLACE INTO matches 
            VALUES (?,?,?,?,?,?,?,?,?)
        ''', matches)
        print(f"Добавлено {len(matches)} матчей")
    
    db.commit()
    db.close()
    print("Парсинг завершен успешно!")

if __name__ == "__main__":
    main()
