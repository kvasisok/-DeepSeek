import sys
import os
from pathlib import Path
from utils.predict import calculate_probabilities
from utils.db_operations import load_matches
from utils.report import generate_report
from utils.archive import save_prediction, create_backup
from utils.colors import TermColors as tc

def supports_color():
    if sys.platform == 'win32':
        return False
    return sys.stdout.isatty()

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_main_menu():
    while True:
        clear_screen()
        print(f"{tc.HEADER}=== Система прогнозирования ===")
        print(f"{tc.OKBLUE}1. Выбрать матч")
        print("2. Создать бэкап")
        print(f"0. Выход{tc.ENDC}")
        
        choice = input("\nВыберите действие: ")
        return choice

def select_match(matches):
    clear_screen()
    print(f"{tc.HEADER}=== Доступные матчи ===")
    for i, match in enumerate(matches, 1):
        print(f"{i}. {match['home_team']} vs {match['away_team']}")
    
    try:
        choice = int(input("\nНомер матча (0-назад): "))
        if choice == 0:
            return None
        return matches[choice-1]
    except:
        input("Ошибка выбора! Нажмите Enter...")
        return None

def backup_menu():
    clear_screen()
    print(f"{tc.HEADER}=== Создание бэкапа ===")
    try:
        backup_path = create_backup()
        print(f"{tc.OKGREEN}✅ Бэкап создан:{tc.ENDC}\n{backup_path}")
    except Exception as e:
        print(f"{tc.FAIL}❌ Ошибка:{tc.ENDC} {e}")
    input("\nНажмите Enter...")

def main():
    if not supports_color():
        for attr in dir(tc):
            if not attr.startswith('__'):
                setattr(tc, attr, '')
    
    while True:
        choice = show_main_menu()
        
        if choice == "1":
            matches = load_matches()
            match = select_match(matches)
            if not match:
                continue
                
            probs = calculate_probabilities(
                float(match['home_odd']),
                float(match['draw_odd']),
                float(match['away_odd'])
            )
            
            report = generate_report(match, probs)
            print(report)
            save_prediction(match['id'], report)
            input("\nНажмите Enter...")
            
        elif choice == "2":
            backup_menu()
            
        elif choice == "0":
            break

if __name__ == "__main__":
    main()
