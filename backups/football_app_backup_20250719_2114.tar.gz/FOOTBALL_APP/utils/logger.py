import logging
from pathlib import Path

log_path = Path(__file__).parent.parent / 'logs' / 'app.log'
log_path.parent.mkdir(exist_ok=True)

logging.basicConfig(
    filename=str(log_path),
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-7s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

def log(action, message):
    logging.info(f"{action.ljust(10)} | {message}")
