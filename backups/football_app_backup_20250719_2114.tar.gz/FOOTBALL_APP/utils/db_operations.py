import csv
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / 'db' / 'matches.csv'

def load_matches():
    """Загрузка матчей из CSV"""
    if not DB_PATH.exists():
        return []
    
    with open(DB_PATH, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def save_match(match_data):
    """Сохранение нового матча"""
    fields = ['id', 'date', 'home_team', 'away_team', 'home_odd', 'draw_odd', 'away_odd']
    
    if not DB_PATH.exists():
        with open(DB_PATH, 'w') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
    
    with open(DB_PATH, 'a') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writerow(match_data)
