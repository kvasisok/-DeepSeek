from datetime import datetime
from pathlib import Path
import tarfile
import os

def save_prediction(match_id, prediction):
    """Сохранение прогноза в файл"""
    filename = f"pred_{datetime.now().strftime('%Y%m%d_%H%M')}_{match_id}.md"
    path = Path(__file__).parent.parent / 'db' / 'predictions' / filename
    path.parent.mkdir(exist_ok=True)
    with open(path, 'w') as f:
        f.write(prediction)

def create_backup():
    """Создание полного бэкапа проекта"""
    backup_dir = Path(__file__).parent.parent / 'backups'
    backup_dir.mkdir(exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M')
    backup_name = f'football_app_backup_{timestamp}.tar.gz'
    
    with tarfile.open(backup_dir / backup_name, 'w:gz') as tar:
        tar.add(
            Path(__file__).parent.parent,
            arcname=os.path.basename(Path(__file__).parent.parent),
            filter=lambda x: None if '__pycache__' in x.name else x
        )
    return str(backup_dir / backup_name)
