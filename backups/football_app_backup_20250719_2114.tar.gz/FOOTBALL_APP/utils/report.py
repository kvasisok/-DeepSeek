from datetime import datetime
from .colors import TermColors as tc

def generate_report(match, probabilities):
    """Генерация цветного отчета"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    # Форматирование с цветами
    header = f"{tc.OKGREEN}{tc.BOLD}## Детальный прогноз матча{tc.ENDC}"
    teams = f"{tc.BOLD}{match['home_team']} vs {match['away_team']}{tc.ENDC}"
    date = f"{tc.OKBLUE}📅 {match['date']} | ⏱ {timestamp}{tc.ENDC}"
    
    return f"""
{header}
{teams}  
{date}

{tc.UNDERLINE}📊 Вероятности исходов:{tc.ENDC}
{tc.WARNING}П1{tc.ENDC}: {match['home_odd']} ({probabilities['home']:.1f}%)
{tc.WARNING}Ничья{tc.ENDC}: {match['draw_odd']} ({probabilities['draw']:.1f}%)
{tc.WARNING}П2{tc.ENDC}: {match['away_odd']} ({probabilities['away']:.1f}%)

{tc.UNDERLINE}💡 Рекомендации:{tc.ENDC}
1. {tc.OKGREEN}Основная ставка{tc.ENDC}: {get_main_bet(probabilities)}
2. {tc.OKBLUE}Альтернатива{tc.ENDC}: {get_alternative_bet(probabilities)}
"""

def get_main_bet(probs):
    if probs['home'] > 45: return f"{tc.OKGREEN}П1{tc.ENDC}"
    if probs['away'] > 45: return f"{tc.OKGREEN}П2{tc.ENDC}"
    return f"{tc.OKGREEN}X{tc.ENDC}"

def get_alternative_bet(probs):
    if probs['draw'] > 35: return "Фора (+0.5)"
    return "Тотал > 2.5"
