import requests

def get_odds(match_id):
    try:
        url = "https://odds.p.rapidapi.com/v4/sports/soccer_england_pl/events"
        headers = {
            "X-RapidAPI-Key": "your_api_key",  # Замените на реальный ключ
            "X-RapidAPI-Host": "odds.p.rapidapi.com"
        }
        response = requests.get(url, headers=headers)
        return response.json()
    except Exception as e:
        return {"error": str(e)}
