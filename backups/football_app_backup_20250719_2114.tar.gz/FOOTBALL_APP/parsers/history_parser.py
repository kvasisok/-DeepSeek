import requests
from datetime import datetime

def fetch_history(team_id, api_key="005b8a3887ac4870920d909a7e31c7c5"):
    try:
        url = f"https://api.football-data.org/v4/teams/{team_id}/matches?status=FINISHED&limit=5"
        headers = {"X-Auth-Token": api_key}
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        return [match for match in response.json().get('matches', []) 
                if datetime.fromisoformat(match['utcDate'][:-1]) > datetime(2023, 1, 1)]
    except Exception as e:
        print(f"Ошибка при получении истории: {e}")
        return []
