import sqlite3
import requests
import json
from datetime import datetime

FOOTBALL_API_KEY = "005b8a3887ac4870920d909a7e31c7c5"
DB_PATH = "/storage/emulated/0/FOOTBALL/db/football.db"
REQUEST_DELAY = 6.1

def save_static_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Получаем список всех команд
    cursor.execute("SELECT id FROM teams")
    team_ids = [row[0] for row in cursor.fetchall()]
    
    for team_id in team_ids:
        try:
            # Получаем полные данные о команде
            url = f"http://api.football-data.org/v4/teams/{team_id}"
            response = requests.get(url, headers={'X-Auth-Token': FOOTBALL_API_KEY})
            data = response.json()
            
            # Сохраняем venue
            venue = data.get('venue', {})
            cursor.execute('''
                INSERT OR REPLACE INTO venues 
                (id, name, city, capacity, surface, lat, lng, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                venue.get('id'),
                venue.get('name'),
                venue.get('city'),
                venue.get('capacity'),
                venue.get('grass'),
                venue.get('latitude'),
                venue.get('longitude'),
                datetime.now().isoformat()
            ))
            
            # Сохраняем статические данные команды
            cursor.execute('''
                INSERT OR REPLACE INTO teams_static
                (team_id, founded, club_colors, venue_id)
                VALUES (?, ?, ?, ?)
            ''', (
                team_id,
                data.get('founded'),
                data.get('clubColors'),
                venue.get('id')
            ))
            
            # Обновляем ссылку в основной таблице
            cursor.execute('''
                UPDATE teams SET venue_id = ? WHERE id = ?
            ''', (venue.get('id'), team_id))
            
            print(f"Сохранены данные для команды ID {team_id}")
            
        except Exception as e:
            print(f"Ошибка для команды {team_id}: {str(e)}")
        
        time.sleep(REQUEST_DELAY)
    
    conn.commit()
    conn.close()
    print("Все статические данные сохранены!")

if __name__ == "__main__":
    save_static_data()
