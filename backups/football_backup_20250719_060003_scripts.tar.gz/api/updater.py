import time
import logging
from datetime import datetime
from db_handler import save_match
from football_data_loader import get_matches

logging.basicConfig(filename='updater.log', level=logging.INFO)

def update_matches():
    while True:
        try:
            logging.info(f"\n=== Начало обновления {datetime.now()} ===")
            matches = get_matches()
            
            if not matches:
                logging.warning("Пустой ответ от API")
                continue
                
            count = 0
            for match in matches.get('matches', []):
                if save_match(match):
                    count += 1
            
            logging.info(f"Обновлено {count} матчей")
            logging.info(f"Следующее обновление в {datetime.fromtimestamp(time.time() + 6*3600)}")
            
        except Exception as e:
            logging.error(f"Критическая ошибка: {str(e)}", exc_info=True)
        
        time.sleep(6 * 3600)  # 6 часов в секундах

if __name__ == "__main__":
    update_matches()
