import requests
import sqlite3
from time import sleep

DB_PATH = "/storage/emulated/0/FOOTBALL/db/football.db"
API_KEY = "005b8a3887ac4870920d909a7e31c7c5"
API_URL = "https://api.football-data.org/v4/teams"

def process_venue(venue):
    """Безопасная обработка venue данных"""
    if isinstance(venue, str):
        return {'name': venue}
    if not isinstance(venue, dict):
        return {'name': 'Unknown Venue'}
    return {
        'name': venue.get('name', 'Unknown Venue').strip(),
        'lat': venue.get('latitude'),
        'lng': venue.get('longitude')
    }

def process_team(team):
    """Обработка данных команды"""
    if not isinstance(team, dict):
        return None
        
    venue = process_venue(team.get('venue', {}))
    return {
        'id': team['id'],
        'name': team['name'],
        'short_name': team.get('shortName', ''),
        'venue_name': venue['name'],
        'venue_lat': venue.get('lat'),
        'venue_lng': venue.get('lng'),
        'updated_at': int(time.time())  # Добавляем временную метку
    }

def fetch_teams():
    """Загрузка данных команд"""
    headers = {'X-Auth-Token': API_KEY}
    response = requests.get(API_URL, headers=headers)
    response.raise_for_status()
    return response.json()

def save_to_db(teams):
    """Сохранение в базу данных"""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        
        # Проверяем существование колонки updated_at
        cursor.execute("PRAGMA table_info(teams)")
        columns = [col[1] for col in cursor.fetchall()]
        has_updated_at = 'updated_at' in columns
        
        for team in teams:
            if has_updated_at:
                cursor.execute("""
                    INSERT OR REPLACE INTO teams 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    team['id'],
                    team['name'],
                    team['short_name'],
                    team['venue_name'],
                    team['venue_lat'],
                    team['venue_lng'],
                    team['updated_at']
                ))
            else:
                cursor.execute("""
                    INSERT OR REPLACE INTO teams (id, name, short_name, venue_name, venue_lat, venue_lng)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    team['id'],
                    team['name'],
                    team['short_name'],
                    team['venue_name'],
                    team['venue_lat'],
                    team['venue_lng']
                ))
        conn.commit()

def main():
    """Основная функция"""
    try:
        data = fetch_teams()
        teams = [process_team(team) for team in data.get('teams', []) if team]
        save_to_db(teams)
        print(f"Успешно обновлено {len(teams)} команд")
        return True
    except Exception as e:
        print(f"Ошибка: {str(e)}")
        return False

if __name__ == "__main__":
    import argparse
    import time
    parser = argparse.ArgumentParser()
    parser.add_argument("--full-update", action="store_true")
    args = parser.parse_args()
    
    if args.full_update:
        main()
